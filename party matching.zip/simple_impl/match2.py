'''
Created on Apr 26, 2019

@author: kulka
'''
from pip._vendor.msgpack.fallback import xrange
import random
import time

class Party(object):
    num_heros = 0;
    num_kicks = 0;
    pair = 0;
    
    def __init__(self, params):
        print("Party started!!!")
        self.num_heros = 0;
        self.num_kicks = 0;
        self.pair = 0;
    
    def superhero_checkin(self, name):
        print("superhero ",name," checked in")
        self.num_heros += 1
        print("\t\t\t\t\t\t\tHeros: ", self.num_heros)
        
    def sidekick_checkin(self, name):
        print("sidekick ",name," checked in")
        self.num_kicks += 1
        print("\t\t\t\t\t\t\tKicks: ", self.num_kicks)
        
    def superhero_checkout(self, sup):
        if(self.num_heros > 0 and self.num_kicks > 0):
            self.num_heros -= 1
            self.num_kicks -= 1
            self.pair += 1
            print("superhero ",sup," agreed and left with sidekick ")
        print("\t\t\t\t\t\t\tHeros: ", self.num_heros, " kicks: ", self.num_kicks)
        
    def sidekick_checkout(self, kick):
        if(self.num_heros > 0 and self.num_kicks > 0):
            self.num_heros -= 1
            self.num_kicks -= 1
            self.pair += 1
            print("sidekick ",kick," agreed and left with superhero ")                
        print("\t\t\t\t\t\t\tHeros: ", self.num_heros, " kicks: ", self.num_kicks)
        
def participant_generator(name, role, party):
    # print('Inside participant generator')
    if(role):        
        party.superhero_checkin(name)
        print("Superhero requested sidekick...")
        if party.num_kicks > 1 :
            while bool(random.getrandbits(1)):
                yield "sidekick refused"   
            party.superhero_checkout(name)
    
    else:
        party.sidekick_checkin(name)
        print("Sidekick requested superhero...")
        if party.num_heros > 1 :
            while bool(random.getrandbits(1)):
                yield "superhero refused"
            party.sidekick_checkout(name)                      
        
def main():
    # print("Inside main")
    p = Party([])
    num_heros = 0;
    num_kicks = 0;
    
    participants = []
    for i in xrange(20):
        if random.randint(0, 1) == 1:
            pg = participant_generator(i, True, p)
            num_heros += 1
        else:
            pg = participant_generator(i, False, p)
            num_kicks += 1
        participants.append(pg)
        
    t0 = time.time()
    
    while len(participants) > 0 and time.time() - t0 < 5:
        task = random.choice(participants)               
        try:
            print(task.__next__())
            #task.__next__()
        except StopIteration:
            participants.remove(task)
    
    print ('heroes: %s' % num_heros)
    print ('sidekicks: %s' % num_kicks) 
    print ('pairs: %s' % int(p.pair))
    
    assert min(num_heros, num_kicks) == int(p.pair)

    
if __name__ == '__main__':
    main()
